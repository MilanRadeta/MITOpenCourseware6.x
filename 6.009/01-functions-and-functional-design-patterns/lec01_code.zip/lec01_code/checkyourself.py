def square(x):
    return x*x

foo = square

x = [square, foo]
