def mixtape(songs, target_duration):
    """
    Given a dictionary of songs (mapping titles to durations), as well as a
    total target duration, return a set of song titles such that the sum of
    those songs' durations equals the target_duration.

    If no such set exists, return None instead.

    >>> songs = {'A': 5, 'B': 10, 'C': 6, 'D': 2}
    >>> mixtape(songs, 11) == {'A', 'C'}
    True
    >>> mixtape(songs, 1000) == None
    True
    >>> mixtape(songs, 21) == {'A', 'B', 'C'}
    True
    """
    raise NotImplementedError


if __name__ == '__main__':
    import doctest
    doctest.testmod()
